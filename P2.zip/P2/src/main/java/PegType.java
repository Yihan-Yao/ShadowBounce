/** enum class defining type of pegs */

public enum PegType {
	blue_peg,
	blue_vertical_peg,
	blue_horizontal_peg,
	grey_peg,
	grey_vertical_peg,
	grey_horizontal_peg,
	red_peg,
	red_vertical_peg,
	red_horizontal_peg,
	green_peg,
	green_vertical_peg,
	green_horizontal_peg
}
